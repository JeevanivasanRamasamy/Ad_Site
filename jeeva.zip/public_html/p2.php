<?php 

session_start();
if (!isset($_SESSION['check'])) {
  
  header('location:signin.php?msg=<p class="signupessage">Make signin to access Ad-site</p>');
}
 ?>
<?php
error_reporting(0); 
$con=new mysqli('localhost','id14748725_jeeva','Wu78#m+o<)Ak33N!','id14748725_adsite');
if($con->connect_errno) 
{
  echo $con->connect_error;
  die();
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Ad-site | Product ad</title>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="font-awesome.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Comic+Neue:wght@700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style type="text/css">
.footer
{
  height: auto;
  background: #303030;
}
body
{
  padding: 0;
  width: 100%;
    height: 100%;
  margin: 0;
}
#a
{
  padding-top: 60px;
  height:auto;
  background-color: white;
  font-family: 'Comic Neue', cursive;

}
.navbar-inverse {
    background-color: #303030;
    border-color: #303030;
}
.navbar-inverse .navbar-toggle {
    border-color: #303030;
}
.spinner
{
  width: 80px;
  height: 80px;
  border:2px solid #1d9d74;
  border-top: 3px solid #f3f3f3;
  border-radius: 100%;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  animation: spin 0.8s infinite linear;
  
}
@keyframes spin {
  from
  {
       transform: rotate(0deg);
  }
  to
  {
       transform: rotate(360deg);

  }

}
#overlay
{
  height: 100%;
  width: 100%;
  background-color:#1d9d74;
  position: fixed;
  left: 0;
  top: 0;
}

</style>
<!--remove 000webhost water mark-->
<style>
  img[src*="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]
  {
    display: none;
  }
</style>
<body>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
    <div id="overlay">
        <div class="spinner"></div>
   </div>
   <!--script for preloader-->
   <script type="text/javascript">
      var overlay = document.getElementById("overlay");
        window.addEventListener('load', function()
        {
          overlay.style.display = 'none';
        })
  </script>
  <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" style="color: #d9d9d9;font-family: 'Comic Neue', cursive;" href="explore.php"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
        <a class="navbar-brand" style="color: #d9d9d9;font-family: 'Comic Neue', cursive;letter-spacing:2px;">Product ad</a>

      </div>
    </div>
  </nav>
  <!--body-->

  <div class="container-fluid text-center" id="a" style="font-family: 'Comic Neue', cursive;padding-left: 25px;">
      <div class="text-center">
         <h3>Find more product ad here..</h3> 
      </div><br>
     <?php 
      $sql="SELECT * FROM product order by id desc";
      $result=$con->query($sql);
      if ($result->num_rows>0) 
      {
        while ($row=$result->fetch_array()) 
        {
        
          echo "Product category: ";
          echo $row['category'];
          echo "<br>";
          echo "Product brand: ";
          echo $row['brand'];
          echo "<br>";
          echo "Product name: ";
          echo $row['name'];
          echo "<br>";
          echo "Product availablity: ";
          echo $row['availablity'];
          echo "<br>";
          echo "Contact: ";
          echo $row['email'];
          echo "<br>";
          if ($row['more']=="") {
            echo "";
          }else
          {
            echo "More details: ";
          echo $row['more'];
          }
          echo "<br>";
          echo "<br><hr>"; 
        }
      }
      else
      {
        echo "no product ads yet";
      }


      ?>
  </div>
  <!--footer-->
    
<div class="footer" style="font-family: 'Comic Neue', cursive;">
    <div class="container">
      <h3 class="text-center" ><small style="letter-spacing:1px; color: #fff;">Let's connect.</small></h3>
      <br>
        <div class="text-center" style="font-size: 20px;letter-spacing: 15px;">
             <a href="https://www.facebook.com/jeevanivasan.ramasamy" style="color: #bfbfbf;"><i class="fa fa-facebook"></i></a>
             <a href="https://www.linkedin.com/in/jeeva-nivasan-ramasamy-357405181" style="color: #bfbfbf;"><i class="fa fa-linkedin"></i></a>
             <a href="https://github.com/JeevanivasanRamasamy" style="color: #bfbfbf;"><i class="fa fa-github"></i></a>
             <a href="https://instagram.com/the.nivas?igshid=1eg1vfvnmhz83" style="color: #bfbfbf;"><i class="fa fa-instagram" aria-hidden="true"></i></a>
             <a href="https://mobile.twitter.com/Jeeva_Nivasan" style="color: #bfbfbf;"><i class="fa fa-twitter"></i></a>
        </div>
        <br>  <hr>
          <p class="text-center" style="color: #fff; letter-spacing:1px;"><i class="fa fa-copyright" aria-hidden="true"></i> 2020 Exclusive. | Design by JEEVA</p>
    </div>
  </div>
</body>
</html>