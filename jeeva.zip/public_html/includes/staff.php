<?php 
error_reporting(0); 
$con=new mysqli('localhost','id14748725_jeeva','Wu78#m+o<)Ak33N!','id14748725_adsite');
if($con->connect_errno) 
{
  echo $con->connect_error;
  die();
}
				if (isset($_POST['submit'])) 
				{
					$company=$_POST['company'];
					$job=$_POST['job'];
					$qualification=$_POST['qualification'];
					$experience=$_POST['experience'];
					$skills=$_POST['skills'];
					$email=$_POST['email'];
					$more=$_POST['more'];
					$sql="INSERT INTO staff (company,job,qualification,experience,skills,email,more) VALUES ('$company','$job','$qualification','$experience','$skills','$email','$more')";
					if ($con->query($sql)) 
					{

						header('Location: ../explore.php?msgstaff=<p class="signupessage">Success, Click below to view posted ad</p>');
					}
					else
					{
						echo "image not stored";	
					}
				}
				else
				{
					echo "plese enter fields";
				}

				 ?>