<?php 

session_start();
if (!isset($_SESSION['check'])) {
	
	header('location:signin.php?msg=<p class="signupessage">Make signin to access Ad-site</p>');
}
 ?>
<?php
error_reporting(0); 
$con=new mysqli('localhost','id14748725_jeeva','Wu78#m+o<)Ak33N!','id14748725_adsite');
if($con->connect_errno) 
{
  echo $con->connect_error;
  die();
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Review</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  	<link rel="stylesheet" type="text/css" href="index.css">
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
  	<link rel="stylesheet" href="font-awesome.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Comic+Neue:wght@700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style type="text/css">
*
{
	scroll-behavior: smooth;
}
.footer
{
	height: auto;
	background: #303030;
}
body
{
	padding: 0;
	margin: 0;
    width: 100%;
    height: 100%;
}
#a
{
	padding-top: 90px;
	height:auto;
	background-color: #1d9d74;
	font-family: 'Comic Neue', cursive;

}
.navbar-inverse {
    background-color: #303030;
    border-color: #303030;
}
.navbar-inverse .navbar-toggle {
    border-color: #303030;
}
.spinner
{
  	width: 80px;
  	height: 80px;
	border:2px solid #1d9d74;
	border-top: 3px solid #f3f3f3;
  	border-radius: 100%;
	position: absolute;
	top: 0;
	bottom: 0;
    left: 0;
	right: 0;
	margin: auto;
    animation: spin 0.8s infinite linear;
 }
@keyframes spin 
{
  from
  {
       transform: rotate(0deg);
  }
  to
  {
       transform: rotate(360deg);

  }

}
#overlay
{
  	height: 100%;
  	width: 100%;
	background-color:#1d9d74;
 	position: fixed;
  	left: 0;
  	top: 0;
}
img[src*="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]
{
	display: none;
}
</style>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
    <div id="overlay">
        <div class="spinner"></div>
   	</div>

 <!--script for preloader-->
   <script type="text/javascript">
	    var overlay = document.getElementById("overlay");
        window.addEventListener('load', function()
        {
	        overlay.style.display = 'none';
        })
	</script>

	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#target">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" style="color: #d9d9d9;font-family: 'Comic Neue', cursive;letter-spacing:2px;"><b>Ad-site</b></label></a>
			</div>
			<div class="collapse navbar-collapse" id="target" style="font-family: 'Open Sans', sans-serif;">
				<ul class="nav navbar-nav navbar-right" style="letter-spacing:2px;font-family: 'Comic Neue', cursive;">
				<li><a href="home.php"><i class="fa fa-home" aria-hidden="true"></i><b> Home</b></a></li>
				<li><a href="explore.php"><i class="fa fa-search" aria-hidden="true"></i><b> Explore</b></a></li>
				<li><a href="myaccount.php"><i class="fa fa-user" aria-hidden="true"></i><b> My Account</b></a></li>
				<li><a href="report.php"><i class="fa fa-file-text" aria-hidden="true"></i><b> Project Report</b></a></li>
				<li><a href="feedback.php"><i class="fa fa-comments" aria-hidden="true"></i><b style="color:#d9d9d9;"> Send review</b></a></li>
				</ul>
			</div>
		</div>
	</nav>
<!--body-->
	<div class="container-fluid" id="a" style="font-family: 'Comic Neue', cursive;">
	    <div class="text-center" style="padding-left:15px">
			<img src="image/drawing.png" style="width: 200px; height: 200px;"><br><br>
		</div>
		<h2  style="font-family: 'Comic Neue', cursive;letter-spacing:2px;color: white;" class="text-center"><b  style="text-shadow:2px 2px #666666;">Send your review..</b>
		</h2><br>
		<div class="row">
			<div class="col-xs-offset-1 col-xs-10  col-lg-offset-4 col-lg-4" class="text-center">
				<form action="feedback.php" method="post" autocomplete="off">
					<div class="input-group form-group" style="letter-spacing: 1px;">
						<span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
						<input type="text" name="name" placeholder="Your Name" class="form-control" id="first" required="">
					</div>
					<div class="input-group form-group" style="letter-spacing: 1px;">
						<span class="input-group-addon"><i class="fa fa-envelope" aria-hidden="true"></i></span>
						<input type="email" name="email" placeholder="Your E-Mail" class="form-control" id="email" required="">
					</div>
					<div class="input-group form-group" style="letter-spacing: 1px;">
						<span class="input-group-addon"><i class="fa fa-comments" aria-hidden="true"></i></span>
						<textarea class="form-control" name="comments" rows="3" placeholder="Your Review" id="comment" required=""></textarea>
					</div>
					<div class="text-center">
						<button type="submit" name="submit" class="btn btn-lg" style="background-color: #1d9d74;border-style: solid;border-width: 1px;border-color: white;color: white;font-family: 'Comic Neue', cursive;"><i class="fa fa-check" aria-hidden="true"></i> <b>Submit</b></button>
						<button type="reset" value="reset" class="btn btn-lg" style="background-color: #1d9d74;border-style: solid;border-width: 1px;border-color: white;color: white;font-family: 'Comic Neue', cursive;"><i class="fa fa-times" aria-hidden="true"></i> <b>Clear form</b></button>
					</div>
				</form>
					<!--feedback alert message-->
				<script src="sweetalert.min.js"></script>
				<script type="text/javascript">
					function alertsuccess()
					{
			            swal("Review posted!", "scroll down to see posted review..");
					}
				</script>
<!--insert data-->
				<?php 
				if (isset($_POST['submit'])) 
				{
					$name=$_POST['name'];
					$email=$_POST['email'];
					$comments=$_POST['comments'];
					if ($name!=""&&$email!=""&&$comments!="")
					{
						
					$sql="INSERT INTO feedback (name,email,comments) VALUES ('$name','$email','$comments')";
					if ($con->query($sql)) 
					{
	               echo "<script>alertsuccess();</script>";
					}
					else
					{
						echo "<script>alert('please try again later');</script>";	
					}
				}
				}

				 ?>
			</div>
		</div>
		<br><br><br>
<!--print review-->
<div class="container">
  	<div class="jumbotron text-center">
    	<h3 class="text-center">REVIEW | Ad-site</h3><br><hr>
			
			    <?php 
				$sql="SELECT name,email,comments FROM feedback order by id desc";
				if ($result=$con->query($sql)) 
				{
  					if ($result->num_rows)
  					 {
    					while ($row=$result->fetch_object())
    					{
      						echo "<b>NAME: </b>";
      						echo $row->name;
      						echo '<br>';
      						echo '<br>';
      						echo "<b>EMAIL: </b>";
      						echo $row->email;
      						echo '<br>';
      						echo '<br>';
      						echo "<b>COMMENTS: </b>";
      						echo $row->comments;
      						echo '<br>';
      						echo '<br>';
      						echo '<hr>';
      						echo '<br>';
      					}
      				}
      			}
      		?>
		
    
  	</div>
  	<div class="text-center">
		 <a href="#" class="btn btn-lg" style="background-color: #1d9d74;border-style: solid;border-width: 1px;border-color: white;color: white;font-family: 'Comic Neue', cursive;"><i class="fa fa-angle-double-up" aria-hidden="true"></i> Go top</a><br><br>
	 </div><br><br><br>
 </div>
</div>

<!--footer-->
	<div class="footer" style="font-family: 'Comic Neue', cursive;">
		<div class="container">
			<h3 class="text-center" ><small style="letter-spacing:1px; color: #fff;">Let's connect.</small></h3><br>
				<div class="text-center" style="font-size: 20px;letter-spacing: 15px;">
 						 <a href="https://www.facebook.com/jeevanivasan.ramasamy" style="color: #bfbfbf;"><i class="fa fa-facebook"></i></a>
						 <a href="https://www.linkedin.com/in/jeeva-nivasan-ramasamy-357405181" style="color: #bfbfbf;"><i class="fa fa-linkedin"></i></a>
						 <a href="https://github.com/JeevanivasanRamasamy" style="color: #bfbfbf;"><i class="fa fa-github"></i></a>
						 <a href="https://instagram.com/the.nivas?igshid=1eg1vfvnmhz83" style="color: #bfbfbf;"><i class="fa fa-instagram" aria-hidden="true"></i></a>
						 <a href="https://mobile.twitter.com/Jeeva_Nivasan" style="color: #bfbfbf;"><i class="fa fa-twitter"></i></a>
				</div><br><hr>
        	<p class="text-center" style="color: #fff; letter-spacing:1px;font-family: 'Comic Neue', cursive;"><i class="fa fa-copyright" aria-hidden="true"></i> 2020 Exclusive. | Design by JEEVA</p>
		</div>
	</div>
<!--script to close navbar on click-->
    <script type="text/javascript">
		$(document).on('click','.navbar-collapse.in',function(e)
		{
			if ($(e.target).is('a')) {
				$(this).collapse('hide');
			}
		}

			);
	</script>
	<!--script to avoid resubmission-->
	<script>
	if (window.history.replaceState) {
		window.history.replaceState( null,null,window.location.href);
	    
	}
    </script>
</body>
</html>