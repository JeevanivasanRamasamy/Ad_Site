<!DOCTYPE html>
<html>
<head>
	<title>Ad-site</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  	<link rel="stylesheet" type="text/css" href="index.css">
  	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
  	<link rel="stylesheet" href="font-awesome.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Comic+Neue:wght@700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style type="text/css">

*{
scroll-behavior: smooth;
}
@keyframes slidein {
  0% {
    margin-left: 0%;
  }
  50% {
    margin-left: 100px;
  }
  100% {
    margin-left: 0%;
  }
}
.footer
{
	height: auto;
	background: #303030;
}
body
{

	width: 100%;
	height: 100%;


}
.spinner
{
	width: 80px;
	height: 80px;
	border:2px solid #1d9d74;
	border-top: 3px solid #f3f3f3;
	border-radius: 100%;
	position: absolute;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
	margin: auto;
	animation: spin 0.8s infinite linear;
	
}
@keyframes spin {
	from
	{
       transform: rotate(0deg);
	}
	to
	{
       transform: rotate(360deg);

	}

}
#overlay
{
	height: 100%;
	width: 100%;
	background-color:#1d9d74;
	position: fixed;
	left: 0;
	top: 0;
}
#a
{
	padding-top: 70px;
	height:auto;
	background-color: #1d9d74;
	font-family: 'Comic Neue', cursive;

}
.navbar-inverse {
    background-color: #303030;
    border-color: #303030;
}
.navbar-inverse .navbar-toggle {
    border-color: #303030;
}
</style>
<!--remove 000webhost water mark-->
<style>
	img[src*="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]
	{
		display: none;
	}
</style>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
   <div id="overlay">
        <div class="spinner"></div>
   </div>
   <!--script for preloader-->
   <script type="text/javascript">
	    var overlay = document.getElementById("overlay");
        window.addEventListener('load', function()
        {
	        overlay.style.display = 'none';
        })
	</script>
    <nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#target">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" style="color: #d9d9d9;font-family: 'Comic Neue', cursive;letter-spacing:2px;"><b>Ad-site</b></label></a>
			</div>
			<div class="collapse navbar-collapse" id="target" style="font-family: 'Open Sans', sans-serif;">
				<ul class="nav navbar-nav navbar-right" style="letter-spacing:2px;font-family: 'Comic Neue', cursive;">
				<li><a href="signin.php"><i class="fa fa-sign-in" aria-hidden="true"></i><b> Sign in</b></a></li>
				<li><a href="signup.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i><b> Sign up</b></a></li>
				</ul>
			</div>
		</div>
	</nav>
	<!--body-->
	<div class="container-fluid" id="a">
	    <div class="text-center">
	        <marquee>
	        <h4 style="font-family: 'Comic Neue', cursive;letter-spacing:2px;color: white;text-shadow:1px 1px black">“Stay Home Stay Safe”</h4>
	    </marquee><br>
		<div style="padding-top:13px;">
		    <img src="image/email.png" style="width: 200px; height: 200px;" alt="Ad-site/fox-email">
		</div>
		</div>
			<h1 class="text-center" style="padding-top: 20px;font-family: 'Comic Neue', cursive;letter-spacing:2px;color: white;"><b  style="text-shadow:2px 2px #666666;">Ad-site</b></h1>
			<h4 class="text-center" style="padding-top: 3px;font-family: 'Comic Neue', cursive;letter-spacing:2px;color: white;text-shadow:1px 1px black">Online advertising made easy..</h4><br>
			<div class="text-center">
		<a href="signin.php" class="btn btn-lg" style="background-color: #1d9d74;border-style: solid;border-width: 1px;border-color: white;color: white;font-family: 'Comic Neue', cursive;  animation-duration: 3s;
    animation-name: slidein;
    animation-iteration-count: infinite;">Get Started <i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a></div><br>
			<div class="container text-center">
			    <div><p class="text-center" style="color:white;color:#ffdd80;text-shadow:1px 1px black">OR</p></div>
			    <hr>
			    <h4 style="color:white;padding-top:5px;text-shadow:1px 1px black;" id="km"> Want to know more?<a href="#km" style="color:#8ee4f1;text-shadow:1px 1px black"> Click here</a></h4><br>
			</div>
			<div class="text-center">
		        <img src="image/social-media.png" style="width: 200px; height: 200px;"><br><br>
	    	</div>
			<div style="font-family: 'Comic Neue', cursive;color:white;" class="container" >
			    <h3 style="color:#ffdd80;text-shadow:1px 1px black">What is Ad-site?</h3>
			    <h5 style="line-height: 1.5;">Ad-site is an Online advertising platform for posting product / staff requirement advertisement. And also people can post their skills on Ad-site timeline. Where advertisers can disply their breif advertisement with all the details about the particular product. People can explore and contact seller through their contact details that they have provided along with the product / staff requirement details. Ad-site is developed for the project purpose and I hope it will sounds good for you..</h5><br><br>
			</div>
			<div class="text-center">
		        <img src="image/funds.png" style="width: 200px; height: 200px;"><br><br>
	    	</div>
			<div style="font-family: 'Comic Neue', cursive;color:white;" class="container" >
			    <h3 style="color:#fcbeb6;text-shadow:1px 1px black">Benefits</h3>
			    <h5 style="line-height: 1.5;">Online advertising, also known as web advertising, is a form of marketing and advertising which uses the Internet to deliver promotional marketing messages to consumers. Many consumers find online advertising to fulfill their requirement. People can explore a lot with Ad-site website and sellers may get benefits like huge orders through Ad-site website. You can expand your network and also your bussiness..</h5><br><br>
			</div>
			<div class="text-center">
		        <img src="image/skill.png" style="width: 200px; height: 200px;"><br><br>
	    	</div>
			<div style="font-family: 'Comic Neue', cursive;color:white;" class="container" >
			    <h3 style="color:#f2d1a4;text-shadow:1px 1px black">Creativity</h3>
			    <h5 style="line-height: 1.5;">Creativity can be defined as the use of imagination or orginal ideas to create something, and that is going to change world. In advertising, it is what brings meaning to brand messaging. And the most compelling ads are the ones that grab and maintain your audience's attention. Providing value to your customers by creating meaningfull connections through creative in advertising is one way to create brand recognition..</h5><br><br>
			</div>
			<div class="text-center">
		        <img src="image/skills.png" style="width: 200px; height: 200px;"><br><br>
	    	</div>
			<div style="font-family: 'Comic Neue', cursive;color:white;" class="container" >
			    <h3 style="color:#99cfff;text-shadow:1px 1px black">Skills</h3>
			    <h5 style="line-height: 1.5;">Make your skills visible through Ad-site Timeline. But what kind of skills do you need for a career in Advertising to attract customers? The categories that fall into relevent advertising skills include creativity, communication, project management, personal mastery, media, and marketing. Althrough Ad-site will help you reach your advertiserment to everyone..</h5><br>
			    
			    <div class="text-center">
			        <a href="#" class="btn btn-lg" style="background-color: #1d9d74;border-style: solid;border-width: 1px;border-color: white;color: white;font-family: 'Comic Neue', cursive;"><i class="fa fa-angle-double-up" aria-hidden="true"></i> Go top</a><br><br>
			    </div>
			</div>
	</div>

	
	
		<!--footer-->
		
<div class="footer" style="font-family: 'Comic Neue', cursive;">
		<div class="container">
			<h3 class="text-center" ><small style="letter-spacing:1px; color: #fff;">Let's connect.</small></h3>
			<br>
				<div class="text-center" style="font-size: 20px;letter-spacing: 15px;">
 						 <a href="https://www.facebook.com/jeevanivasan.ramasamy" style="color: #bfbfbf;"><i class="fa fa-facebook"></i></a>
						 <a href="https://www.linkedin.com/in/jeeva-nivasan-ramasamy-357405181" style="color: #bfbfbf;"><i class="fa fa-linkedin"></i></a>
						 <a href="https://github.com/JeevanivasanRamasamy" style="color: #bfbfbf;"><i class="fa fa-github"></i></a>
						 <a href="https://instagram.com/the.nivas?igshid=1eg1vfvnmhz83" style="color: #bfbfbf;"><i class="fa fa-instagram" aria-hidden="true"></i></a>
						 <a href="https://mobile.twitter.com/Jeeva_Nivasan" style="color: #bfbfbf;"><i class="fa fa-twitter"></i></a>
				</div>
      	<br>	<hr>
        	<p class="text-center" style="color: #fff; letter-spacing:1px;"><i class="fa fa-copyright" aria-hidden="true"></i> 2020 Exclusive. | Design by JEEVA</p>
		</div>
	</div>
	<!--script to close navbar on click-->
    <script type="text/javascript">
		$(document).on('click','.navbar-collapse.in',function(e)
		{
			if ($(e.target).is('a')) {
				$(this).collapse('hide');
			}
		}

			);
	</script>
	
</body>
</html>