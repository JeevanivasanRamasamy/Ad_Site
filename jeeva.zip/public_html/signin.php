<!DOCTYPE html>
<html>
<head>
	<title>Sign in</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  	<link rel="stylesheet" type="text/css" href="index.css">
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
  	<link rel="stylesheet" href="font-awesome.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Comic+Neue:wght@700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style type="text/css">
  .signupessage
{
  text-align: center;
  color: #ffdd80;
  font-size: 20px;
  text-shadow:1px 1px black
}
.footer
{
	height: auto;
	background: #303030;
}
body
{
	padding: 0;
	width: 100%;
    height: 100%;
	margin: 0;
}
#a
{
	padding-top: 90px;
	height:auto;
	background-color: #1d9d74;
	font-family: 'Comic Neue', cursive;

}
.navbar-inverse {
    background-color: #303030;
    border-color: #303030;
}
.navbar-inverse .navbar-toggle {
    border-color: #303030;
}
.spinner
{
  width: 80px;
  height: 80px;
  border:2px solid #1d9d74;
  border-top: 3px solid #f3f3f3;
  border-radius: 100%;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  animation: spin 0.8s infinite linear;
  
}
@keyframes spin {
  from
  {
       transform: rotate(0deg);
  }
  to
  {
       transform: rotate(360deg);

  }

}
#overlay
{
  height: 100%;
  width: 100%;
  background-color:#1d9d74;
  position: fixed;
  left: 0;
  top: 0;
}

</style>
<!--remove 000webhost water mark-->
<style>
	img[src*="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]
	{
		display: none;
	}
</style>
<body>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
    <div id="overlay">
        <div class="spinner"></div>
   </div>
   <!--script for preloader-->
   <script type="text/javascript">
	    var overlay = document.getElementById("overlay");
        window.addEventListener('load', function()
        {
	        overlay.style.display = 'none';
        })
	</script>
	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" style="color: #d9d9d9;font-family: 'Comic Neue', cursive;letter-spacing:2px;"><b>Ad-site</b></label></a>
			</div>
		</div>
	</nav>
	<!--body-->

	<div class="container-fluid " id="a" style="font-family: 'Comic Neue', cursive;">
	   <div class="text-center" style="padding-left:30px">
	        <img src="image/padlock.png" style="width: 170px; height: 170px;"><br><br>
	   </div>
		<div class="row">
			<div class="col-xs-offset-1 col-xs-10  col-lg-offset-4 col-lg-4 " style=" border-radius: 15px;">
			    <h1 class="text-center" style="font-family: 'Comic Neue', cursive;letter-spacing:2px;"><b  style="text-shadow:2px 2px #666666;color:#f2d1a4;">SIGN IN..</b></h1>
          <?php
    if (isset($_GET['login'])) {
      if ($_GET['login'] == "empty") {
        echo '<p class="signupessage">All fields required</p>';
      }
      else if ($_GET['login'] == "error") {
        echo '<p class="signupessage">Incorrect Sign in details</p>'; 
      }
      elseif ($_GET['signup'] == "success") {
        echo '<p class="signupessage">Sign in success</p>'; 
    }
    }
  
    ?>
    <?php 
    if (isset($_GET['signup'])) {
      echo $_GET['signup'];
    }

     ?>
     <?php 
    if (isset($_GET['msg'])) {
      echo $_GET['msg'];
    }

     ?>
				<form action="includes/login.inc.php" method="post" autocomplete="off">
                    <div class="form-group">
                        <label for="uid" style="color:white;text-shadow:1px 1px black;">Username:</label>
                        <input type="text" class="form-control" id="uid" name="uid" placeholder="Enter username" required=""
                        style="border-style: solid;border-width: 1px;border-color: white;font-family: 'Comic Neue', cursive;">
                    </div>
                    <div class="form-group">
                        <label for="pwd" style="color:white;text-shadow:1px 1px black;">Password:</label>
                        <input type="password" class="form-control" id="pwd"  name="pwd" placeholder="Enter password" required="" style="border-style: solid;border-width: 1px;border-color: white;font-family: 'Comic Neue', cursive;">
                    </div>
                <div class="text-center"><button type="submit" name="submit" class="btn btn-lg" style="background-color: #1d9d74;border-style: solid;border-width: 1px;border-color: white;color: white;font-family: 'Comic Neue', cursive;"><i class="fa fa-check" aria-hidden="true"></i> Submit</button></div>
                    <br><p style="color:#ffdd80;text-shadow:1px 1px black" class="text-center">OR</p><hr>
                        <div class="text-center"><a href="signup.php" style="color: white;text-shadow:1px 1px black"><h4>Don't have an account ? <b style="color:#8ee4f1;text-shadow:1px 1px black">Sign up</b></h4></a></div>
                </form><br><br><br><br>
			</div>
		</div></div>
	<!--footer-->
		
<div class="footer" style="font-family: 'Comic Neue', cursive;">
		<div class="container">
			<h3 class="text-center" ><small style="letter-spacing:1px; color: #fff;">Let's connect.</small></h3>
			<br>
				<div class="text-center" style="font-size: 20px;letter-spacing: 15px;">
 						 <a href="https://www.facebook.com/jeevanivasan.ramasamy" style="color: #bfbfbf;"><i class="fa fa-facebook"></i></a>
						 <a href="https://www.linkedin.com/in/jeeva-nivasan-ramasamy-357405181" style="color: #bfbfbf;"><i class="fa fa-linkedin"></i></a>
						 <a href="https://github.com/JeevanivasanRamasamy" style="color: #bfbfbf;"><i class="fa fa-github"></i></a>
						 <a href="https://instagram.com/the.nivas?igshid=1eg1vfvnmhz83" style="color: #bfbfbf;"><i class="fa fa-instagram" aria-hidden="true"></i></a>
						 <a href="https://mobile.twitter.com/Jeeva_Nivasan" style="color: #bfbfbf;"><i class="fa fa-twitter"></i></a>
				</div>
      	<br>	<hr>
        	<p class="text-center" style="color: #fff; letter-spacing:1px;"><i class="fa fa-copyright" aria-hidden="true"></i> 2020 Exclusive. | Design by JEEVA</p>
		</div>
	</div>
    <!--script to avoid resubmission-->
  <script>
  if (window.history.replaceState) {
    window.history.replaceState( null,null,window.location.href);
      
  }
    </script>
</body>
</html>