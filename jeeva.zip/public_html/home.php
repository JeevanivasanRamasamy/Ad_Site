<?php 

session_start();
if (!isset($_SESSION['check'])) {
	
	header('location:signin.php?msg=<p class="signupessage">Make signin to access Ad-site</p>');
}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  	<link rel="stylesheet" type="text/css" href="index.css">
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
  	<link rel="stylesheet" href="font-awesome.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Comic+Neue:wght@700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style type="text/css">
.footer
{
	height: auto;
	background: #303030;
}
body
{
	padding: 0;
	margin: 0;
	width: 100%;
    height: 100%;

}
.signupessage
{
  text-align: center;
  color: white;
  font-size: 20px;
}
#a
{
	padding-top: 49px;
	height:auto;
	background-color: #1d9d74;
	font-family: 'Comic Neue', cursive;

}
.navbar-inverse {
    background-color: #303030;
    border-color: #303030;
}
.navbar-inverse .navbar-toggle {
    border-color: #303030;
}
.spinner
{
  width: 80px;
  height: 80px;
  border:2px solid #1d9d74;
  border-top: 3px solid #f3f3f3;
  border-radius: 100%;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  animation: spin 0.8s infinite linear;
  
}
@keyframes spin {
  from
  {
       transform: rotate(0deg);
  }
  to
  {
       transform: rotate(360deg);

  }

}
#overlay
{
  height: 100%;
  width: 100%;
  background-color:#1d9d74;
  position: fixed;
  left: 0;
  top: 0;
}
</style>
<!--remove 000webhost water mark-->
<style>
	img[src*="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"]
	{
		display: none;
	}
</style>
<body>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
    <div id="overlay">
        <div class="spinner"></div>
   </div>
   <!--script for preloader-->
   <script type="text/javascript">
	    var overlay = document.getElementById("overlay");
        window.addEventListener('load', function()
        {
	        overlay.style.display = 'none';
        })
	</script>

	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#target">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" style="color: #d9d9d9;font-family: 'Comic Neue', cursive;letter-spacing:2px;"><b>Ad-site </b></label></a>
			</div>
			<div class="collapse navbar-collapse" id="target" style="font-family: 'Open Sans', sans-serif;">
				<ul class="nav navbar-nav navbar-right" style="letter-spacing:2px;font-family: 'Comic Neue', cursive;">
				<li><a href="home.php"><i class="fa fa-home" aria-hidden="true"></i><b style="color:#d9d9d9;"> Home</b></a></li>
				<li><a href="explore.php"><i class="fa fa-search" aria-hidden="true"></i><b> Explore</b></a></li>
				<li><a href="myaccount.php"><i class="fa fa-user" aria-hidden="true"></i><b> My Account</b></a></li>
				<li><a href="report.php"><i class="fa fa-file-text" aria-hidden="true"></i><b> Project Report</b></a></li>
				<li><a href="feedback.php"><i class="fa fa-comments" aria-hidden="true"></i><b> Send review</b></a></li>
				</ul>
			</div>
		</div>
	</nav>
	<!--body-->
	<div class="container-fluid" id="a" style="font-family: 'Open Sans', sans-serif;">
	    <marquee style="padding-top:13px;"><h4 style="font-family: 'Comic Neue', cursive;letter-spacing:2px;color: white;"><p>Welcome "<?php
                echo $_SESSION["check"]; 
            ?>"</p></h4>
	    </marquee>
	    <br>
	
	    <div class="text-center">
	        <img src="image/monitor.png" style="width: 200px; height: 200px;"><br><br><br>
	        </div>
	   <div class="text-center">
	       <div>
	        <a class="btn btn-lg" style="background-color: #1d9d74;border-style: solid;border-width: 1px;border-color: white;color: white;font-family: 'Comic Neue', cursive;"  data-toggle="collapse" data-target="#demo">Post something on timeline <i class="fa fa-caret-down" aria-hidden="true"></i></a>
	        <div id="demo" class="collapse"> 
	        <div class="row">
			<div class="col-xs-offset-1 col-xs-10  col-lg-offset-4 col-lg-4">
                    <br><br>
				<form action="includes/post.php" method="post" enctype="multipart/form-data">
					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;">
						<span class="input-group-addon"><i class="fa fa-picture-o" aria-hidden="true"></i></span>
						<input type="file" name="image" class="form-control" id="image" required="" placeholder="Add image *">	
					</div>
					</div>
					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-font" aria-hidden="true"></i></span>
						<textarea class="form-control" name="comments" rows="2" placeholder="Add caption *" id="comments" required=""></textarea>
					</div>
					</div>
					<div class="text-center">
						<button type="submit" name="submit" class="btn btn-default" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">Post
						</button>
					</div>
				</form>
			</div>
		</div>
    </div>
</div>
		<br>
		<div>
	        <a class="btn btn-lg" style="background-color: #1d9d74;border-style: solid;border-width: 1px;border-color: white;color: white;font-family: 'Comic Neue', cursive;"  data-toggle="collapse" data-target="#demoo">Post your product ad <i class="fa fa-caret-down" aria-hidden="true"></i></a>
	        <div id="demoo" class="collapse">
	            <div class="row">
			<div class="col-xs-offset-1 col-xs-10  col-lg-offset-4 col-lg-4">
                    <br><br>
				<form action="includes/product.php" method="post" enctype="multipart/form-data">
					
					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-shopping-bag" aria-hidden="true"></i></span>
						<input type="text" name="category" class="form-control" placeholder="Product category eg: beauty,health etc *" required="">
					</div>
					</div>
					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-trademark" aria-hidden="true"></i></span>
						<input type="text" name="brand" class="form-control" placeholder="Product brand eg: Hindustan unilever etc *" required="">
					</div>
					</div>
					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-tag" aria-hidden="true"></i></span>
						<input type="text" name="name" class="form-control" placeholder="Product name eg: Kissan squashes etc *" required="">
					</div>
					</div>
					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-truck" aria-hidden="true"></i></span>
						<input type="text" name="availablity" class="form-control" placeholder="Availablity eg: 500 units *" required="">
					</div>
					</div>
					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-envelope" aria-hidden="true"></i></span>
						<input type="email" name="email" class="form-control" placeholder="Enter your email *" required="">
					</div>
					</div>

					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-info-circle" aria-hidden="true"></i></span>
						<textarea class="form-control" name="more" rows="2" placeholder="Add more details (optional)"></textarea>
					</div>
					</div>
					<div class="text-center">
						<button type="submit" name="submit" class="btn btn-default" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">Post
						</button>
					</div>
				</form>
			</div>
		</div>
             </div>
	   </div>
		<br>
	<div>
	    	<a class="btn btn-lg" style="background-color: #1d9d74;border-style: solid;border-width: 1px;border-color: white;color: white;font-family: 'Comic Neue', cursive;"  data-toggle="collapse" data-target="#demooo">Post staff requirement ad <i class="fa fa-caret-down" aria-hidden="true"></i></a>
	    	<div id="demooo" class="collapse">
	    	    <div class="row">
			<div class="col-xs-offset-1 col-xs-10  col-lg-offset-4 col-lg-4">
                    <br><br>
				<form action="includes/staff.php" method="post" enctype="multipart/form-data">
					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-building" aria-hidden="true"></i></span>
						<input type="text" name="company" class="form-control" placeholder="Company name eg: Zoho,Tcs etc *" required="">
					</div>
					</div>
					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-briefcase" aria-hidden="true"></i></span>
						<input type="text" name="job" class="form-control" placeholder="Job vacancies eg: Full stack developer etc *" required="">
					</div>
					</div>
					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-graduation-cap" aria-hidden="true"></i></span>
						<input type="text" name="qualification" class="form-control" placeholder="Qualification eg: B.E etc *" required="">
					</div>
					</div>
					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-handshake-o" aria-hidden="true"></i></span>
						<input type="text" name="experience" class="form-control" placeholder="Experience eg: 0-3 years *" required="">
					</div>
					</div>
					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-puzzle-piece" aria-hidden="true"></i></span>
						<input type="text" name="skills" class="form-control" placeholder="Required skills eg: HTML,BOOTSTRAP *" required="">
					</div>
					</div>
					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-envelope" aria-hidden="true"></i></span>
						<input type="email" name="email" class="form-control" placeholder="Enter your email *" required="">
					</div>
					</div>

					<div style="font-family: 'Comic Neue', cursive;">
					<div class="input-group form-group" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">
						<span class="input-group-addon"><i class="fa fa-info-circle" aria-hidden="true"></i></span>
						<textarea class="form-control" name="more" rows="2" placeholder="Add more details (optional)"></textarea>
					</div>
					</div>
					<div class="text-center">
						<button type="submit" name="submit" class="btn btn-default" style="letter-spacing: 1px;font-family: 'Comic Neue', cursive;">Post
						</button>
					</div>
				</form>
			</div>
		</div>
             </div>
	</div></div>
		<br>
	    	<div class="text-center">
	    	    <a href="explore.php" class="btn btn-lg" style="background-color: #1d9d74;border-style: solid;border-width: 1px;border-color: white;color: white;font-family: 'Comic Neue', cursive;">Explore <br>timeline/product/requirement ad..</a>
	    	</div>
	    	<br><br><br>
	</div>
	<!--footer-->
		
	<div class="footer" style="font-family: 'Comic Neue', cursive;">
		<div class="container">
			<h3 class="text-center" ><small style="letter-spacing:1px; color: #fff;">Let's connect.</small></h3>
			<br>
				<div class="text-center" style="font-size: 20px;letter-spacing: 15px;">
 						 <a href="https://www.facebook.com/jeevanivasan.ramasamy" style="color: #bfbfbf;"><i class="fa fa-facebook"></i></a>
						 <a href="https://www.linkedin.com/in/jeeva-nivasan-ramasamy-357405181" style="color: #bfbfbf;"><i class="fa fa-linkedin"></i></a>
						 <a href="https://github.com/JeevanivasanRamasamy" style="color: #bfbfbf;"><i class="fa fa-github"></i></a>
						 <a href="https://instagram.com/the.nivas?igshid=1eg1vfvnmhz83" style="color: #bfbfbf;"><i class="fa fa-instagram" aria-hidden="true"></i></a>
						 <a href="https://mobile.twitter.com/Jeeva_Nivasan" style="color: #bfbfbf;"><i class="fa fa-twitter"></i></a>
				</div>
      	<br>	<hr>
        	<p class="text-center" style="color: #fff; letter-spacing:1px;"><i class="fa fa-copyright" aria-hidden="true"></i> 2020 Exclusive. | Design by JEEVA</p>
		</div>
	</div>
	<!--script to close navbar on click-->
    <script type="text/javascript">
		$(document).on('click','.navbar-collapse.in',function(e)
		{
			if ($(e.target).is('a')) {
				$(this).collapse('hide');
			}
		}

			);
	</script>
	<!--script to avoid resubmission-->
	<script>
	if (window.history.replaceState) {
		window.history.replaceState( null,null,window.location.href);
	    
	}
    </script>
</body>
</html>